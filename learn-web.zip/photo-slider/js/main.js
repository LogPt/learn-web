$(function () {

  $('.slider').slick({

    infinite: true,
    speed: 500,
    slidesToShow: 1,
    centerMode: true,
    variableWidth: true
  });
});