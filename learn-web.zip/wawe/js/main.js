$(function(){
  $('.slider').slick({
    dots: true,
    speed: 900,
    arrows: false,
  });
});